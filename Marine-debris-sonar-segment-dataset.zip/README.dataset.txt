# shen-na-seg > 2024-08-08 9:55am
https://universe.roboflow.com/mydata-gsroi/shen-na-seg

Provided by a Roboflow user
License: CC BY 4.0

